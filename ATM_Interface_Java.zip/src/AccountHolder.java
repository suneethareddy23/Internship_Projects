class AccountHolder
{
   private String id = "dvsr123";
   private String pin = "4528";

   public String getId()
   {
     return id;
   }
   
   public String getPin()
   {
     return pin;
   }
   
}